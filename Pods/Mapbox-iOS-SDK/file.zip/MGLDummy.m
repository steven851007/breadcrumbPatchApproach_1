// https://github.com/mapbox/mapbox-gl-native/issues/1426
